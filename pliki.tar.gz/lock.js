var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

document.onkeydown = function (e) {
    if (event.keyCode == 123) {
        return false;
    }

    if (e.ctrlKey && e.shiftKey && e.keyCode == "I".charCodeAt(0)) {
        return false;
    }

    if (e.ctrlKey && e.shiftKey && e.keyCode == "C".charCodeAt(0)) {
        return false;
    }

    if (e.ctrlKey && e.shiftKey && e.keyCode == "J".charCodeAt(0)) {
        return false;
    }

    if (e.ctrlKey && e.keyCode == "S".charCodeAt(0)) {
        return false;
    }

    if (e.ctrlKey && e.keyCode == "C".charCodeAt(0)) {
        return false;
    }

    if (e.ctrlKey && e.keyCode == "V".charCodeAt(0)) {
        return false;
    }

    if (e.ctrlKey && e.keyCode == "X".charCodeAt(0)) {
        return false;
    }

    if (e.ctrlKey && e.keyCode == "X".charCodeAt(0)) {
        return false;
    }

    if (e.keyCode == 116)
        e.preventDefault();
    };

document.addEventListener("contextmenu", (e) => e.preventDefault());

document.addEventListener("developertools", (e) => e.preventDefault());

document.addEventListener("inspect_element", (e) => e.preventDefault());

}
/*
     FILE ARCHIVED ON 18:06:04 Mar 01, 2022 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 23:22:51 May 29, 2025.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 0.617
  exclusion.robots: 0.024
  exclusion.robots.policy: 0.011
  esindex: 0.013
  cdx.remote: 32.181
  LoadShardBlock: 445.672 (3)
  PetaboxLoader3.resolve: 262.173 (3)
  PetaboxLoader3.datanode: 85.484 (4)
  load_resource: 166.026
*/
